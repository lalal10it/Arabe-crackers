from names_dataset.query import NameDataset

__version__ = '1.9.1'
